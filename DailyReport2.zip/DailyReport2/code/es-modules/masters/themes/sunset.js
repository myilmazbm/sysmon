/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 *
 * (c) 2009-2017 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sunset.js';
